package main

import (
	"fmt"
	"net/http"
	"strings"
	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/idfabric"
)

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")
    
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}
    
	metadata := api.Metadata()
	idpNames := strings.Split(metadata["idps"].(string), ",")
    var authenticated = "false"
	for _, idpName := range idpNames {
	    logger.Info("inside for loop:" + idpName)
	    if idpName == "azureoidc" {
	        logger.Info("se", fmt.Sprintf("inside azure oidc if condition"))
	        authenticated, err = session.GetString("EntraID-OIDC.authenticated")
	    } else if idpName == "auth0" {
	        logger.Info("se", fmt.Sprintf("inside auth0 if condition"))
	        authenticated, err = session.GetString("Auth0DemoIDP.authenticated")
	    } else if idpName == "okta" {
	        logger.Info("se", fmt.Sprintf("inside okta if condition"))
	        authenticated, err = session.GetString("Okta.authenticated")
	    } else if idpName == "ping" {
	        logger.Info("se", fmt.Sprintf("inside ping if condition"))
	        authenticated, err = session.GetString("PingOne-OIDC.authenticated")
	    } else if idpName == "1kosmos" {
	        logger.Info("se", fmt.Sprintf("inside 1kosmos if condition"))
	        authenticated, err = session.GetString("1KosmosIDP.authenticated")
	    }
	    logger.Info("IsAuthenticated?" + authenticated)
		//authenticated, err := session.GetString("Entra-ID.authenticated")
		if err != nil {
			logger.Error(
				"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", idpName),
				"error", err.Error(),
			)
		}
		if authenticated == "true" {
			logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", idpName))
			return true
		}
	}
    logger.Info("not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "authenticating user")

	if req.Method == http.MethodGet {
		logger.Info("se", "received GET request, rendering login form html page")
		// ServiceExtensionAssets exposes any assets that may have been bundled with the
        // service extension.
        assets := api.ServiceExtensionAssets()
        // ReadFile returns the file contents as a []byte.
        idpForm, err := assets.ReadFile("LoginPage.html")
        if err != nil {
            logger.Error("se", "failed to read service extension asset file", "error", err.Error())
            http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
            return
        }
        _, _ = rw.Write(idpForm)
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		return
	}

	logger.Debug("se", "parsing form from request")
	err := req.ParseForm()
	if err != nil {
		logger.Error("se", "failed to parse form from request", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	email := req.Form.Get("email")
	domain := strings.Split(email, "@")[1]
	logger.Info("se", fmt.Sprintf("User with domain '%s' is attempting to authenticate", domain))
	
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
    var idpDomainMap = map[string]string{
	"vsathishlive.onmicrosoft.com": "EntraID-OIDC",
	"live.com": "EntraID-OIDC",
	"boeingext.com": "OktaOAuthApp",
	"boeingkosmos.com": "OktaOAuthApp",
	"gds.ey.com": "1KosmosIDP",
	"boeingping.com": "PingOne-OIDC",
	"boeingokta.com": "OktaOAuthApp",
    }
	// Add more domain-to-IDP mappings here
	
    // Check if the domain exists in the idpDomainMap
	selectedIDP, ok := idpDomainMap[domain]
	logger.Info("se", fmt.Sprintf("user is prompted to '%s' IDP for authentication", selectedIDP))
	if !ok {
		logger.Error("se", "no IDP found for domain", "domain", domain)
		http.Error(rw, "No IDP found for the provided domain", http.StatusBadRequest)
		return
	}

	idp, err := api.IdentityProvider(selectedIDP)
	
	if err != nil {
		logger.Error("se", "unable to lookup idp", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}
	
	//idp.Login(rw, req)
    loginHintOption := idfabric.WithLoginHint(email)
    idp.Login(rw, req, loginHintOption)
	return
}