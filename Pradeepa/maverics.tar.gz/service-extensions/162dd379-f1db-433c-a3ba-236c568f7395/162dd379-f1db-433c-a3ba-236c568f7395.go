package main
import (
	"net/http"

	"github.com/strata-io/service-extension/orchestrator"
)

// Note: To use this service extension with a SAML user flow, the signature must include a response writer.
// Ex. func BuildTokenClaims(api orchestrator.Orchestrator, rw, http.ResponseWriter, _ *http.Request) (map[string]any, error)
func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
	logger := api.Logger()
	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return nil, err
	}
	roles, _ := session.GetString("okta.roles")
	return map[string]any{
		"scope": roles,
	}, nil
}